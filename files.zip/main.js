/* ==========================================================================
   BARBEARIA IMPERIAL — main.js

   TUDO que você precisa editar está no bloco CONFIG abaixo.
   Nada mais no site precisa ser alterado: WhatsApp, Instagram, endereço,
   horário, mapa e depoimentos são preenchidos a partir daqui.
   ========================================================================== */

const CONFIG = {

  /* --- Contato --------------------------------------------------------- */

  // Número em formato internacional, só dígitos: 55 + DDD + número
  whatsappNumber: "5547999999999",

  // Como o telefone aparece escrito no rodapé
  whatsappLabel: "(47) 99999-9999",

  // Mensagem enviada quando o cliente clica em um botão genérico de agendar
  whatsappMessage: "Olá! Vim pelo site e quero agendar um horário na Barbearia Imperial.",

  instagramUrl: "https://instagram.com/barbeariaimperial",
  instagramHandle: "@barbeariaimperial",

  /* --- Endereço e horário ---------------------------------------------- */

  // Endereço usado no texto da página, no mapa e no botão do Google Maps
  address: "Av. das Palmeiras, 482 — Centro, Balneário Camboriú - SC",

  // Use \n para quebrar linha
  hours: "Segunda a sábado: 09h às 20h\nDomingo: fechado",

  /* --- Modo demonstração ------------------------------------------------
     Enquanto true, a página exibe um aviso visível de que o conteúdo é de
     demonstração. Troque para false depois de colocar os dados reais.       */

  demoLocation: true,
  demoTestimonials: true,

  /* --- Depoimentos ------------------------------------------------------
     Substitua pelos depoimentos REAIS dos seus clientes (com autorização
     deles) e marque demoTestimonials: false acima.
     Para deixar a seção vazia até ter avaliações reais, use: []            */

  testimonials: [
    {
      text: "Exemplo de depoimento: descreva aqui, com as palavras do próprio cliente, o que ele achou do atendimento.",
      author: "Nome do cliente",
      detail: "cliente há 2 anos",
    },
    {
      text: "Exemplo de depoimento: um comentário sobre pontualidade e hora marcada funciona bem neste espaço.",
      author: "Nome do cliente",
      detail: "cliente há 8 meses",
    },
    {
      text: "Exemplo de depoimento: use um relato sobre corte infantil ou sobre a barba para mostrar variedade.",
      author: "Nome do cliente",
      detail: "cliente há 1 ano",
    },
  ],
};

/* ==========================================================================
   A partir daqui não é necessário editar nada.
   ========================================================================== */

/* --- Links do WhatsApp ---------------------------------------------------- */

function buildWhatsappUrl(service) {
  const message = service
    ? `Olá! Quero agendar "${service}" na Barbearia Imperial.`
    : CONFIG.whatsappMessage;
  return `https://wa.me/${CONFIG.whatsappNumber}?text=${encodeURIComponent(message)}`;
}

document.querySelectorAll("[data-whatsapp]").forEach((el) => {
  el.href = buildWhatsappUrl(el.dataset.service);
  el.target = "_blank";
  el.rel = "noopener";
});

/* --- Textos vindos do CONFIG --------------------------------------------- */

const TEXTS = {
  address: CONFIG.address,
  hours: CONFIG.hours,
  phone: CONFIG.whatsappLabel,
  instagram: CONFIG.instagramHandle,
};

document.querySelectorAll("[data-config]").forEach((el) => {
  const value = TEXTS[el.dataset.config];
  if (value === undefined) return;
  // Quebras de linha do CONFIG viram <br> de forma segura (sem innerHTML)
  el.textContent = "";
  value.split("\n").forEach((line, i) => {
    if (i > 0) el.appendChild(document.createElement("br"));
    el.appendChild(document.createTextNode(line));
  });
});

/* --- Instagram, Google Maps e mapa incorporado --------------------------- */

const instagramLink = document.getElementById("instagramLink");
if (instagramLink) instagramLink.href = CONFIG.instagramUrl;

const encodedAddress = encodeURIComponent(CONFIG.address);

const mapsBtn = document.getElementById("mapsBtn");
if (mapsBtn) mapsBtn.href = `https://www.google.com/maps/search/?api=1&query=${encodedAddress}`;

// Embed público do Google Maps — não exige chave de API
const mapsFrame = document.getElementById("mapsFrame");
if (mapsFrame) mapsFrame.src = `https://www.google.com/maps?q=${encodedAddress}&output=embed`;

/* --- Avisos de conteúdo de demonstração ---------------------------------- */

const locationBadge = document.getElementById("locationDemoBadge");
if (locationBadge && CONFIG.demoLocation) locationBadge.hidden = false;

const testimonialsBadge = document.getElementById("testimonialsDemoBadge");
if (testimonialsBadge && CONFIG.demoTestimonials && CONFIG.testimonials.length) {
  testimonialsBadge.hidden = false;
}

/* --- Menu no celular ------------------------------------------------------ */

const navToggle = document.getElementById("navToggle");
const mainNav = document.getElementById("mainNav");

function setMenu(open) {
  mainNav.classList.toggle("is-open", open);
  navToggle.setAttribute("aria-expanded", String(open));
  navToggle.setAttribute("aria-label", open ? "Fechar menu" : "Abrir menu");
  navToggle.innerHTML = `<svg width="22" height="22" aria-hidden="true"><use href="#icon-${open ? "close" : "menu"}"/></svg>`;
}

if (navToggle && mainNav) {
  navToggle.addEventListener("click", () => setMenu(!mainNav.classList.contains("is-open")));
  mainNav.querySelectorAll("a").forEach((link) => link.addEventListener("click", () => setMenu(false)));
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && mainNav.classList.contains("is-open")) setMenu(false);
  });
}

/* --- Depoimentos ---------------------------------------------------------- */

const track = document.getElementById("testimonialsTrack");
const dotsWrap = document.getElementById("testimonialsDots");
const prevBtn = document.getElementById("testPrev");
const nextBtn = document.getElementById("testNext");

if (track && dotsWrap && prevBtn && nextBtn) {
  const items = CONFIG.testimonials || [];

  if (!items.length) {
    // Sem depoimentos cadastrados: nada de conteúdo inventado na tela
    const empty = document.createElement("p");
    empty.className = "testimonials__empty";
    empty.textContent = "Em breve, avaliações dos nossos clientes.";
    track.parentElement.replaceWith(empty);
    prevBtn.closest(".testimonials__controls").remove();
  } else {
    items.forEach((item) => {
      const card = document.createElement("blockquote");
      card.className = "testimonial";

      const quote = document.createElementNS("http://www.w3.org/2000/svg", "svg");
      quote.setAttribute("class", "testimonial__quote");
      quote.setAttribute("width", "28");
      quote.setAttribute("height", "21");
      quote.setAttribute("aria-hidden", "true");
      const use = document.createElementNS("http://www.w3.org/2000/svg", "use");
      use.setAttribute("href", "#icon-quote");
      quote.appendChild(use);

      const text = document.createElement("p");
      text.className = "testimonial__text";
      text.textContent = item.text;

      const author = document.createElement("footer");
      author.className = "testimonial__author";
      author.textContent = item.author;
      if (item.detail) {
        const detail = document.createElement("span");
        detail.textContent = ` — ${item.detail}`;
        author.appendChild(detail);
      }

      card.append(quote, text, author);
      track.appendChild(card);
    });

    const slides = Array.from(track.children);
    let index = 0;

    const dots = slides.map((_, i) => {
      const dot = document.createElement("button");
      dot.className = "testimonials__dot";
      dot.setAttribute("aria-label", `Ir para o depoimento ${i + 1}`);
      dot.addEventListener("click", () => goTo(i));
      dotsWrap.appendChild(dot);
      return dot;
    });

    function goTo(next) {
      index = (next + slides.length) % slides.length;
      track.style.transform = `translateX(-${index * 100}%)`;
      slides.forEach((s, i) => s.classList.toggle("is-active", i === index));
      dots.forEach((d, i) => d.classList.toggle("is-active", i === index));
    }

    prevBtn.addEventListener("click", () => goTo(index - 1));
    nextBtn.addEventListener("click", () => goTo(index + 1));
    goTo(0);
  }
}

/* --- Ano do rodapé -------------------------------------------------------- */

const yearEl = document.getElementById("year");
if (yearEl) yearEl.textContent = new Date().getFullYear();
