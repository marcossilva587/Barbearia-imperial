# Barbearia Imperial — Landing Page

Landing page estática (HTML + CSS + JavaScript puro), sem frameworks, sem backend e sem
banco de dados. Objetivo único: transformar visitante em agendamento pelo WhatsApp.

## Estrutura

```
index.html    → estrutura e conteúdo da página
style.css     → todo o visual
main.js       → bloco CONFIG (seus dados) + interações
README.md     → este guia
assets/       → pasta que VOCÊ cria para colocar as fotos
```

Os 4 arquivos ficam na raiz do projeto. A pasta `assets/` é a única subpasta, e só
existe quando você a criar para colocar as imagens.

---

## 1. Edite seus dados — um único lugar

Abra **`main.js`**. Tudo o que precisa mudar está no bloco `CONFIG`, no topo do arquivo:

| Campo | Para que serve |
|---|---|
| `whatsappNumber` | Número com 55 + DDD, só dígitos. Alimenta **todos** os botões da página |
| `whatsappLabel` | Como o telefone aparece escrito no rodapé |
| `whatsappMessage` | Mensagem pré-preenchida nos botões genéricos de agendar |
| `instagramUrl` / `instagramHandle` | Link e @ exibidos no rodapé |
| `address` | Usado no texto, no mapa incorporado e no botão do Google Maps |
| `hours` | Horário de funcionamento (use `\n` para quebrar linha) |
| `demoLocation` | `true` mostra o aviso de "dados de demonstração". Troque para `false` ao colocar os reais |
| `demoTestimonials` | Mesma lógica para a seção de depoimentos |
| `testimonials` | A lista de depoimentos exibidos |

Você não precisa mexer no HTML para trocar endereço, horário, telefone ou Instagram —
esses textos são preenchidos a partir do `CONFIG` em todos os lugares onde aparecem.

### Depoimentos

A página **não publica avaliações inventadas como se fossem reais**. Os textos que vêm
no arquivo são exemplos genéricos e a seção exibe um aviso visível de "Depoimentos de
demonstração" enquanto `demoTestimonials` estiver `true`.

Quando tiver avaliações reais (com autorização dos clientes para publicar):

1. Substitua os itens de `CONFIG.testimonials` pelos depoimentos verdadeiros.
2. Mude `demoTestimonials` para `false` — o aviso some sozinho.

Se preferir não exibir nada até ter avaliações, deixe a lista vazia:

```js
testimonials: [],
```

A seção passa a mostrar apenas "Em breve, avaliações dos nossos clientes."

---

## 2. Coloque suas fotos

Crie uma pasta `assets/` na raiz do projeto e coloque as imagens com estes nomes:

| Arquivo | Onde aparece | Proporção recomendada |
|---|---|---|
| `assets/hero.jpg` | Imagem grande do topo | vertical, ~4:5 (ex.: 1000×1250) |
| `assets/galeria-1.jpg` | Galeria, quadro alto | vertical |
| `assets/galeria-2.jpg` | Galeria | quadrada |
| `assets/galeria-3.jpg` | Galeria | quadrada |
| `assets/galeria-4.jpg` | Galeria, quadro largo | horizontal, ~2:1 |
| `assets/galeria-5.jpg` | Galeria | quadrada |
| `assets/galeria-6.jpg` | Galeria, quadro alto | vertical |
| `assets/og-image.jpg` | Miniatura ao compartilhar o link | 1200×630 |

**Enquanto o arquivo não existir**, o espaço aparece como um quadro reservado mostrando
o nome do arquivo esperado. Isso é intencional: assim a página nunca exibe uma foto de
banco de imagens fingindo ser da sua barbearia. Basta colocar o arquivo com o nome certo
e ele aparece — sem tocar no código.

### Otimizando as imagens (importante para a velocidade)

- Redimensione para no máximo **1600px** no lado maior. Foto de celular tem 4000px e
  pesa 5 MB sem necessidade.
- Exporte em **JPEG com qualidade 75–80**, ou em **WebP** se quiser arquivos ainda menores.
- Mire em **até 200 KB por imagem**.
- Ferramentas gratuitas: [Squoosh](https://squoosh.app) ou [TinyPNG](https://tinypng.com).

Se usar WebP, troque a extensão nos `src` dentro do `index.html` (procure por `assets/`).

A página já usa `loading="lazy"` nas fotos da galeria e `fetchpriority="high"` na imagem
do topo, então só o essencial carrega de imediato.

---

## 3. Rodar localmente

Como é um site estático, você pode abrir o `index.html` direto no navegador. Mas para o
comportamento ficar idêntico ao de produção, rode um servidor local:

**Com Python** (já vem instalado na maioria dos computadores):
```bash
python3 -m http.server 3000
```

**Com Node.js:**
```bash
npx serve .
```

Depois abra **http://localhost:3000**.

---

## 4. Publicar na Vercel

### Opção A — pelo site, sem terminal

1. Crie uma conta gratuita em [vercel.com](https://vercel.com).
2. Suba a pasta do projeto para um repositório no GitHub.
3. Na Vercel: **Add New → Project** e selecione o repositório.
4. Em **Framework Preset**, deixe **Other** (não há build a rodar).
5. Clique em **Deploy**. Em cerca de um minuto o site está no ar.

### Opção B — pela CLI

```bash
npm install -g vercel
vercel          # primeiro deploy (aceite as opções padrão)
vercel --prod   # publica as atualizações depois
```

Nenhum `vercel.json` é necessário: a Vercel detecta o site estático e serve o
`index.html` como página inicial.

### Domínio próprio

No painel do projeto: **Settings → Domains**, adicione seu domínio e aponte no seu
provedor os registros de DNS que a Vercel indicar.

---

## 5. Checklist antes de divulgar o link

- [ ] `whatsappNumber` trocado pelo número real e testado no celular
- [ ] Endereço e horário reais no `CONFIG`, com `demoLocation: false`
- [ ] Depoimentos reais (ou lista vazia), com `demoTestimonials: false`
- [ ] Fotos colocadas em `assets/` e otimizadas
- [ ] Página aberta no próprio celular, rolando do topo ao rodapé

---

## Notas técnicas

- **Performance:** zero bibliotecas JavaScript. O único recurso externo são as fontes do
  Google Fonts (com `preconnect` e `display=swap`). Os ícones são SVG embutidos no HTML e
  reaproveitados via `<use>`, então não há requisições de imagem para a interface.
- **Mobile:** barra de agendamento fixa no rodapé em telas de até 760px, respeitando a
  área segura do iPhone. `overflow-x: hidden` e quebra de palavras longas garantem que
  nada ultrapasse a largura da tela.
- **Conversão:** cada seção termina com uma próxima ação explícita, e cada serviço tem
  seu próprio botão que já abre o WhatsApp com o serviço escolhido na mensagem.
- **SEO:** `title`, `meta description`, tags Open Graph, `lang="pt-BR"` e `theme-color`.
- **Mapa:** usa o embed público do Google Maps a partir do endereço do `CONFIG` —
  não exige chave de API.
- **Acessibilidade:** link para pular direto ao conteúdo, foco visível no teclado,
  rótulos nos botões de navegação e suporte a `prefers-reduced-motion`.
